import boto3
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
import os
import mysql.connector
import json
import math

def lambda_handler(event, context):
    
    # 引数の取得
    if event.get('target_days'):
        target_days = event['target_days']
    else:
        target_days = 7
        
    print('target_days = ' + str(target_days))

    conn = mysql.connector.connect(
        host = os.environ['db_host'],
        user = os.environ['db_user'],
        password = os.environ['db_pass'],
        db = os.environ['db_name']
    )

    cursor = conn.cursor(dictionary=True)
    
    # slides 取得
    slides = get_slides(target_days, cursor)
    
    if len(slides) == 0:
        print('finished. no hit slides')
        return

    # logs取得とS3への書き出し
    exec_logs(slides, cursor)
    
    conn.close()
    cursor.close()
    
    return {
        'statusCode': 200,
        'body': 'finished'
    }
    
# slides 取得    
def get_slides(target_days, cursor):
    print('start get slides')

    now = datetime.now()
    dt = now - timedelta(days = target_days)
    form = dt.strftime("%Y-%m-%d %H:%M:%S")
    to = now.strftime("%Y-%m-%d %H:%M:%S")
    
    print('from = ' + form + ', to = ' + to)
    
    slides_sql = "SELECT * FROM slides WHERE date_close BETWEEN %s AND %s"
    param = (form, to)

    cursor.execute(slides_sql, param)
    slides = cursor.fetchall()
    
    print(f'get slides {cursor.rowcount} slides')
    
    return slides


# logs取得とS3への書き出し
def exec_logs(slides, cursor):
    for slide in slides:
        print('start exec logs. slide_code = ' + slide['slide_code'])
        
        # ログの件数を取得
        count_sql = "SELECT count(*) AS cnt FROM logs WHERE slide_code = %s"
        param = (slide['slide_code'],)
        cursor.execute(count_sql, param)
        rows = cursor.fetchone()['cnt']
        print(f'get count {rows} rows')

        limit = 10000
        offset = 0
        i = 0
        loop_cnt = math.ceil(rows / limit)
        
        # 書き込み先ファイルを用意
        tmp_file_name = '/tmp/' + slide['slide_code'] + '_' + datetime.now().strftime("%Y%m%d%H%M%S")
        fp = open(tmp_file_name, 'w', encoding='utf-8')
        fp.write("time\tuid\taction\tpage\tdevice\tuser_agent\r\n")

        # 分割して取得し、ファイルに書き込み
        while i < loop_cnt:
            logs_sql = "SELECT * FROM logs WHERE slide_code = %s ORDER BY id LIMIT %s OFFSET %s"
            param = (slide['slide_code'], limit, offset, )
            
            cursor.execute(logs_sql, param)
            logs = cursor.fetchall()
            
            print(f'get logs {offset} / {rows} rows')
            offset = offset + limit
            i = i + 1

            for log in logs:
                data = \
                    log['operate_time'].strftime("%Y/%m/%d %H:%M:%S") + "\t" + \
                    str(log['user_id']) + "\t" + \
                    log['action'] + "\t" + \
                    str(log['page']) + "\t" + \
                    log['device'] + "\t" + \
                    log['user_agent'] + "\r\n"
                fp.write(data)

        fp.close()

        print('start upload s3')
    
        # S3アップロード
        s3 = boto3.resource('s3')
        bucket = os.environ['s3_bucket']
        s3_fiil_name = 'operation_logs/' + slide['client_code'] + '/slide_log_' + slide['slide_code'] + '.tsv'
        s3.meta.client.upload_file(tmp_file_name, bucket, s3_fiil_name)
        os.remove(tmp_file_name)
        
        print('end upload s3')
    
        print('end exec logs. slide_code = ' + slide['slide_code'])
        
    return